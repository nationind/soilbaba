# Soil Baba 🌱

Affordable, scientific soil testing service for Indian farmers — in local languages.

Deployed using React + Vite + GitHub Pages.

Made with ❤️ by Kar